#include "Game.h"

void clearinterface()
{
#ifdef _WIN32
	system("cls");
#endif
#ifdef __unix__
	system("clear");
#endif
}

void sleeping(int time)
{
#ifdef __unix__
	sleep(time);
#endif
#ifdef _WIN32
	Sleep(time * 1000);
#endif
}

int InitializeCard(Card arraycard[])
/*
Initialise le paquet de carte et incr�mente chaque structure de carte dans le tableau arraycard.
*/
{
	int specific_card = 0;
	char symbol = '0';
	for (int i = 1; i <= 4; i++)
	{
		switch (i)
		{
		case 1:
			symbol = 'c';
			break;
		case 2:
			symbol = 'd';
			break;
		case 3:
			symbol = 'h';
			break;
		case 4:
			symbol = 's';
			break;
		}
		for (int a = 1; a <= 13; a++)
		{
			arraycard[specific_card].value = a;
			arraycard[specific_card].symbol = symbol;
			specific_card++;
			if (specific_card > 52)
			{
				exit(-1);
			}
		}
	}
	return 0;
}

// Fonction de m�lange des cartes
void shuffle(Card arraycard[])
{
	srand(time(0));
	for (int i = 0; i <= 51; i++)
	{
		int j = rand() % 51;
		struct card t = arraycard[i];
		arraycard[i] = arraycard[j];
		arraycard[j] = t;
	}
}

// Fonction attribution des cartes au diff�rent layer
void AttribueCards(Card arraylayer1[], Card arraylayer2[], Card arraylayer3[], Card arraylayer4[], Card arraydeck[], Card arraycard[])
{
	for (int a = 0; a <= 23; a++)
	{
		arraydeck[a] = arraycard[a];
	}
	int compteur = 0;
	for (int a = 24; a <= 26; a++)
	{
		arraylayer1[compteur] = arraycard[a];
		compteur++;
	}
	compteur = 0;
	for (int a = 27; a <= 32; a++)
	{
		arraylayer2[compteur] = arraycard[a];
		compteur++;
	}
	compteur = 0;
	for (int a = 33; a <= 41; a++)
	{
		arraylayer3[compteur] = arraycard[a];
		compteur++;
	}
	compteur = 0;
	for (int a = 42; a <= 51; a++)
	{
		arraylayer4[compteur] = arraycard[a];
		compteur++;
	}
}

// Fonction de jeu
void game(Card arraygame[], Card arraylayer1[], Card arraylayer2[], Card arraylayer3[], Card arraylayer4[], Card arraydeck[]) {
  int cardplay = 0;
  int *pointeurcardplay = &cardplay;
	int x = 0;
  int *pointeurx = &cardplay;
	int m = 23;
  int *pointeurm = &m;
  int plays = 0;
  int *pointeurplays = &plays;
	int choicelayer;
	arraygame[x] = arraydeck[m];
	m--;
  welcome();
	sleeping(3);
	while (1) {
    plays ++;
		clearinterface();
    visual(arraylayer1, arraylayer2, arraylayer3, arraylayer4, arraygame, &x);
		scanf("%d", &choicelayer);
		switch (choicelayer) {
		case 0:
			if (m < 0) {
				printf("\n Plus de carte dans la pioches \n");
			}
			else {
				arraygame[x + 1] = arraydeck[m];
				x++;
				m--;
			}
			break;
		case 1:
			printf("\nQuel carte jouer (1 a 3) : ");
			scanf("%d", &cardplay);
			printf("\n");
			if (cardplay == 1 && arraylayer2[0].value == 0 && arraylayer2[1].value == 0 && ((arraylayer1[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer1[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer1, &cardplay, &x);
			}
			else if (cardplay == 2 && arraylayer2[2].value == 0 && arraylayer2[3].value == 0 && ((arraylayer1[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer1[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer1, &cardplay, &x);
			}
			else if (cardplay == 3 && arraylayer2[4].value == 0 && arraylayer2[5].value == 0 && ((arraylayer1[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer1[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer1, &cardplay, &x);
			}
			else {
				printf("Choix invalide\n");
			}
			break;
		case 2:
			printf("\nQuel carte jouer (1 a 6) : ");
			scanf("%d", &cardplay);
			printf("\n");
			if (cardplay == 1 && arraylayer3[0].value == 0 && arraylayer3[1].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else if (cardplay == 2 && arraylayer3[1].value == 0 && arraylayer3[2].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else if (cardplay == 3 && arraylayer3[3].value == 0 && arraylayer3[4].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else if (cardplay == 4 && arraylayer3[4].value == 0 && arraylayer3[5].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else if (cardplay == 5 && arraylayer3[6].value == 0 && arraylayer3[7].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else if (cardplay == 6 && arraylayer3[7].value == 0 && arraylayer3[8].value == 0 && ((arraylayer2[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer2[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer2, &cardplay, &x);
			}
			else {
				printf("Choix invalide\n");

			}
			break;
		case 3:
			printf("\nQuel carte jouer (1 a 9) : ");
			scanf("%d", &cardplay);
			printf("\n");
			if (arraylayer4[cardplay - 1].value == 0 && arraylayer4[cardplay].value == 0 && ((arraylayer3[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer3[cardplay - 1].value - 1) == arraygame[x].value)) {
			  tozero(arraygame, arraylayer3, &cardplay, &x);
			}
			else {
				printf("Choix invalide\n");
			}
			break;
		case 4:
			printf("\nQuel carte jouer (1 a 10) : ");
			scanf("%d", &cardplay);
			printf("\n");
			if ((arraylayer4[cardplay - 1].value + 1) == arraygame[x].value || (arraylayer4[cardplay - 1].value - 1) == arraygame[x].value) {
			  tozero(arraygame, arraylayer4, &cardplay, &x);
			}
			else {
				printf("\nChoix invalide\n");
			}
			break;
		case 5:
			printf("\nMerci d'avoir jouer, au plaisir de vous revoir !\n");
      exit(0);
			break;
		case 6:
			restart();
			break;
		case 7:
			saveGame(arraygame, arraydeck, &plays);
      exit(0);
			break;
		default:
			printf("\nChoix invalide \n");
			break;
		}
		sleeping(1);
	}
}

void welcome()
{
  printf("____________________________________________________________\n");
	printf("\n");
	printf("     ----------------- Bienvenu dans -------------------\n");
	printf("     #######                                             \n");
	printf("	#    #####  # #####  ######   ##   #    #  ####  \n");
	printf("	#    #    # # #    # #       #  #  #   #  #      \n");
	printf("	#    #    # # #    # #####  #    # ####    ####  \n");
	printf("	#    #####  # #####  #      ###### #  #        # \n");
	printf("	#    #   #  # #      #      #    # #   #  #    # \n");
	printf("	#    #    # # #      ###### #    # #    #  ####  \n");
	printf("\n");
	printf("____________________________________________________________\n");
	printf("\n");
}

void visual(Card arraylayer1[], Card arraylayer2[], Card arraylayer3[], Card arraylayer4[], Card arraygame[], int *pointeurx)
{
		printf("Tripeaks game by Alexis, Gabriel and Roman           ----------    -----------\n");
		printf("                                                     |  Game  |    | Couche  |\n");
		printf("---------------------------------------------------------------    -----------\n");
		printf("|                                                             |    |         |\n");
		printf("|           %02d%c               %02d%c               %02d%c           |    |    1    |\n", arraylayer1[0].value, arraylayer1[0].symbol, arraylayer1[1].value, arraylayer1[1].symbol, arraylayer1[2].value, arraylayer1[2].symbol);
		printf("|                                                             |    |         |\n");
		printf("|        %02d%c   %02d%c         %02d%c   %02d%c         %02d%c   %02d%c        |    |    2    |\n", arraylayer2[0].value, arraylayer2[0].symbol, arraylayer2[1].value, arraylayer2[1].symbol, arraylayer2[2].value, arraylayer2[2].symbol, arraylayer2[3].value, arraylayer2[3].symbol, arraylayer2[4].value, arraylayer2[4].symbol, arraylayer2[5].value, arraylayer2[5].symbol);
		printf("|                                                             |    |         |\n");
		printf("|     %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c     |    |    3    |\n", arraylayer3[0].value, arraylayer3[0].symbol, arraylayer3[1].value, arraylayer3[1].symbol, arraylayer3[2].value, arraylayer3[2].symbol, arraylayer3[3].value, arraylayer3[3].symbol, arraylayer3[4].value, arraylayer3[4].symbol, arraylayer3[5].value, arraylayer3[5].symbol, arraylayer3[6].value, arraylayer3[6].symbol, arraylayer3[7].value, arraylayer3[7].symbol, arraylayer3[8].value, arraylayer3[8].symbol);
		printf("|                                                             |    |         |\n");
		printf("|  %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c   %02d%c  |    |    4    |\n", arraylayer4[0].value, arraylayer4[0].symbol, arraylayer4[1].value, arraylayer4[1].symbol, arraylayer4[2].value, arraylayer4[2].symbol, arraylayer4[3].value, arraylayer4[3].symbol, arraylayer4[4].value, arraylayer4[4].symbol, arraylayer4[5].value, arraylayer4[5].symbol, arraylayer4[6].value, arraylayer4[6].symbol, arraylayer4[7].value, arraylayer4[7].symbol, arraylayer4[8].value, arraylayer4[8].symbol, arraylayer4[9].value, arraylayer4[9].symbol);
		printf("|                                                             |    |         |\n");
		printf("---------------------------------------------------------------    -----------\n");
		printf("\n-------------\n");
		printf("| jeu : %02d%c |\n", arraygame[*pointeurx].value, arraygame[*pointeurx].symbol);
		printf("-------------\n");
		printf("\n\n0 = piocher dans la reserve\n1 a 4 = Choix de la couche\n5 = fin du jeu\n6 = Recommencer une nouvelle partie\n7 = Sauvegarder \n");
		printf("\nVotre choix : ");
}

void tozero(Card arraygame[], Card layer[], int *pointeurcardplay, int *pointeurx)
{
  arraygame[*pointeurx + 1] = layer[*pointeurcardplay - 1];
  layer[*pointeurcardplay - 1].value = 0;
  layer[*pointeurcardplay - 1].symbol = 'x';
  *pointeurx += 1;
}

// Fonction de restart et appel de la generation du jeu
void restart()
{
	printf("\nVous avez decider de relancer la partie\n");
	printf("... Nouvelle partie en cours ... \n");
	generateGame();
}

// Fonction de generation du jeu
void generateGame() {

	// Packet de cartes entier
	Card arraycard[52];

	// Tableau couche 1 � 4
	Card arraylayer1[3];
	Card arraylayer2[6];
	Card arraylayer3[9];
	Card arraylayer4[10];

	// Tableau pioche
	Card arraydeck[24];
	Card arraygame[52];

	// Initialisation du random
	srand(time(NULL));

	// Fonction d'initialisation des cartes
	InitializeCard(arraycard);

	// Fonction de m�lange des cartes
	shuffle(arraycard);

	// Fonction attribution des cartes au diff�rent layer
	AttribueCards(arraylayer1, arraylayer2, arraylayer3, arraylayer4, arraydeck, arraycard);

	// Fonction de jeu
	game(arraygame, arraylayer1, arraylayer2, arraylayer3, arraylayer4, arraydeck);
}

// Fonction qui sauvegarde un resum� de la partie
void saveGame(Card arraygame[], Card arraydeck[], int *plays) {

	char path[200];
	getcwd(path, 200);

	FILE* fptr;
	fptr = fopen("resume.txt", "a+");

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);
	fprintf(fptr, "\nVous avez demande un resume le: %d-%02d-%02d %02d:%02d:%02d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

	fprintf(fptr, "Vous avez joue ces cartes :\n");
	for (int i = 0; i < *plays; i++) {
		fprintf(fptr, "%d%c - ", arraygame[i].value, arraygame[i].symbol);
	}

	fprintf(fptr, "\nIl y avait ces cartes dans la reserve :\n");
	for (int i = 0; i < 23; i++) {
		fprintf(fptr, "%d%c - ", arraydeck[i].value, arraydeck[i].symbol);
	}
	fprintf(fptr, "\n---FIN DE PARTIE---\n");
	fclose(fptr);

	clearinterface();
	
	printf("---SAUVEGARDE TERMINE ---\n");
	printf("Fichier sauvegarde a l'espace de fichier : %s\\resume.txt \n", path);
	system("pause");
}

