#include "Game.h"

int main(int argc, char* argv[]) {

	generateGame();

	return 0;
}