#include "Game.h"

int main(int argc, char* argv[]) {
  detectos();
	generateGame();
	return 0;
}